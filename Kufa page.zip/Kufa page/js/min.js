(function ($) {
	"use strict";
	
	/*=============================================
    =     Menu sticky & Scroll to top      =
=============================================*/
$(window).on('scroll', function () {
    var scroll = $(window).scrollTop();
    if (scroll < 100) {
        $("#sticky-header").removeClass("sticky-menu");

    } else {
        $("#sticky-header").addClass("sticky-menu");
    }
});

	
// testmonial-active
	$('.testmonial-active').owlCarousel({
		loop:true,
		margin: 30,
		nav:false,
		navText: ['<span class="lnr lnr-arrow-left"></span>','<span class="lnr lnr-arrow-right"></span>'],
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			920:{
				items:1
			},
			1000:{
				items:1,
			}
		}
	});
// brand-active
	$('.brand-active').owlCarousel({
		loop:true,
		margin: 30,
		nav:false,
		navText: ['<span class="lnr lnr-arrow-left"></span>','<span class="lnr lnr-arrow-right"></span>'],
		responsive:{
			0:{
				items:2,
			},
			600:{
				items:3,
			},
			920:{
				items:5,
			},
			1000:{
				items:5,
			}
		}
	});

// odometer active
$('.odometer').appear(function (e) {
    var odo = $(".odometer");
    odo.each(function () {
        var countNumber = $(this).attr("data-count");
        $(this).html(countNumber);
    });
});
	
	
})(jQuery);